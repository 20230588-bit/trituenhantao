from pathlib import Path
import cv2


# ==========================================
# ĐƯỜNG DẪN PROJECT
# ==========================================

BASE_DIR = Path(__file__).resolve().parent.parent
DATASET_DIR = BASE_DIR / "dataset"


print("==========================================")
print("       KIEM TRA DATASET KHUON MAT")
print("==========================================")
print(f"Dataset: {DATASET_DIR}")
print()


# ==========================================
# KIỂM TRA DATASET
# ==========================================

if not DATASET_DIR.exists():
    print("Khong tim thay thu muc dataset!")
    exit()


student_folders = [
    folder for folder in DATASET_DIR.iterdir()
    if folder.is_dir()
]


if not student_folders:
    print("Dataset chua co du lieu!")
    exit()


total_images = 0


# ==========================================
# KIỂM TRA TỪNG SINH VIÊN
# ==========================================

for folder in sorted(student_folders):

    images = list(folder.glob("*.jpg"))

    print(f"Sinh vien: {folder.name}")
    print(f"So luong anh: {len(images)}")

    valid_images = 0

    for image_path in images:

        image = cv2.imread(str(image_path))

        if image is not None:
            valid_images += 1

    print(f"Anh doc duoc: {valid_images}")

    if valid_images < 20:
        print("WARNING: So anh dang it!")

    else:
        print("OK: Dataset dat yeu cau!")

    print()

    total_images += valid_images


# ==========================================
# TỔNG KẾT
# ==========================================

print("==========================================")
print(f"Tong so anh: {total_images}")
print(f"So sinh vien: {len(student_folders)}")
print("==========================================")