import cv2
from pathlib import Path
import time

from database import update_face_folder

# ==========================================
# ĐƯỜNG DẪN PROJECT
# ==========================================

BASE_DIR = Path(__file__).resolve().parent.parent
DATASET_DIR = BASE_DIR / "dataset"


# ==========================================
# HÀM CHỤP KHUÔN MẶT
# ==========================================

def capture_faces(student_id):

    student_id = str(student_id).strip()

    if not student_id:
        return False, "Mã sinh viên không được để trống."

    # ==========================================
    # TẠO THƯ MỤC SINH VIÊN
    # ==========================================

    student_folder = DATASET_DIR / student_id
    student_folder.mkdir(
        parents=True,
        exist_ok=True
    )

    # ==========================================
    # LOAD HAAR CASCADE
    # ==========================================

    cascade_path = (
        cv2.data.haarcascades
        + "haarcascade_frontalface_default.xml"
    )

    face_cascade = cv2.CascadeClassifier(
        cascade_path
    )

    if face_cascade.empty():
        return False, "Không thể tải bộ phát hiện khuôn mặt."

    # ==========================================
    # MỞ CAMERA
    # ==========================================

    camera = cv2.VideoCapture(0)

    if not camera.isOpened():
        return False, "Không mở được camera."

    # ==========================================
    # CÀI ĐẶT
    # ==========================================

    count = len(
        list(student_folder.glob("*.jpg"))
    )

    last_capture = 0
    capture_delay = 0.7

    stable_start = None
    stable_time = 0.5

    print()
    print("==========================================")
    print("       THU THẬP DỮ LIỆU KHUÔN MẶT")
    print("==========================================")
    print(f"Mã sinh viên: {student_id}")
    print(f"Thư mục: {student_folder}")
    print()
    print("Đưa khuôn mặt vào giữa camera.")
    print("Giữ khuôn mặt ổn định.")
    print("Chương trình sẽ tự động chụp.")
    print("Nhấn Q để dừng.")
    print("==========================================")

    # ==========================================
    # VÒNG LẶP CAMERA
    # ==========================================

    while True:

        ret, frame = camera.read()

        if not ret:
            break

        # Lật camera giống gương
        frame = cv2.flip(frame, 1)

        # Chuyển grayscale
        gray = cv2.cvtColor(
            frame,
            cv2.COLOR_BGR2GRAY
        )

        # Làm ảnh rõ hơn
        gray = cv2.equalizeHist(gray)

        # ======================================
        # PHÁT HIỆN KHUÔN MẶT
        # ======================================

        faces = face_cascade.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=4,
            minSize=(80, 80)
        )

        # ======================================
        # CÓ KHUÔN MẶT
        # ======================================

        if len(faces) > 0:

            # Lấy khuôn mặt lớn nhất
            x, y, w, h = max(
                faces,
                key=lambda face:
                face[2] * face[3]
            )

            # Vẽ khung
            cv2.rectangle(
                frame,
                (x, y),
                (x + w, y + h),
                (0, 255, 0),
                2
            )

            # Bắt đầu tính thời gian ổn định
            if stable_start is None:
                stable_start = time.time()

            stable_duration = (
                time.time() - stable_start
            )

            # ==================================
            # TRẠNG THÁI
            # ==================================

            if stable_duration < stable_time:

                text = "Giu khuon mat on dinh..."

            else:

                text = "Dang chup..."

                current_time = time.time()

                # Đủ thời gian giữa 2 ảnh
                if (
                    current_time - last_capture
                    >= capture_delay
                ):

                    # Cắt khuôn mặt
                    face_image = gray[
                        y:y + h,
                        x:x + w
                    ]

                    count += 1

                    file_path = (
                        student_folder
                        / f"{student_id}_{count:03d}.jpg"
                    )

                    # Lưu ảnh
                    cv2.imwrite(
                        str(file_path),
                        face_image
                    )

                    last_capture = current_time

                    print(
                        f"Da chup anh {count}: "
                        f"{file_path.name}"
                    )

        # ======================================
        # KHÔNG CÓ KHUÔN MẶT
        # ======================================

        else:

            stable_start = None

            text = "Khong thay khuon mat"

        # ======================================
        # HIỂN THỊ TRẠNG THÁI
        # ======================================

        cv2.putText(
            frame,
            text,
            (20, 40),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (0, 255, 0),
            2
        )

        # Số lượng ảnh
        cv2.putText(
            frame,
            f"So anh: {count}",
            (20, 80),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 0),
            2
        )

        # Hướng dẫn
        cv2.putText(
            frame,
            "Nhan Q de thoat",
            (20, 115),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (255, 255, 255),
            2
        )

        # ======================================
        # HIỂN THỊ CAMERA
        # ======================================

        cv2.imshow(
            "Face Data Collection",
            frame
        )

        # ======================================
        # NHẤN Q ĐỂ THOÁT
        # ======================================

        key = cv2.waitKey(1) & 0xFF

        if key == ord("q"):
            break

    # ==========================================
    # ĐÓNG CAMERA
    # ==========================================

    camera.release()

    cv2.destroyAllWindows()

    print()
    print("==========================================")
    print(f"Hoan thanh! Da co {count} anh.")
    print(f"Thu muc: {student_folder}")
    print("==========================================")

    if count == 0:
        return False, "Chưa chụp được ảnh khuôn mặt."

    return True, f"Đã chụp {count} ảnh cho sinh viên {student_id}."