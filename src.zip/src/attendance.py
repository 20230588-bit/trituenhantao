from database import get_connection


# ==========================================================
# KIỂM TRA SINH VIÊN ĐÃ ĐIỂM DANH HÔM NAY CHƯA
# ==========================================================

def check_attendance_today(student_id):

    conn = get_connection()

    try:
        cursor = conn.cursor()

        cursor.execute("""
            SELECT AttendanceID
            FROM Attendance
            WHERE StudentID = ?
              AND CAST(CheckInTime AS DATE) = CAST(GETDATE() AS DATE)
        """, student_id)

        result = cursor.fetchone()

        return result is not None

    finally:
        conn.close()


# ==========================================================
# THÊM ĐIỂM DANH
# ==========================================================

def add_attendance(student_id):

    conn = get_connection()

    try:
        cursor = conn.cursor()

        # Kiểm tra đã điểm danh hôm nay
        cursor.execute("""
            SELECT AttendanceID
            FROM Attendance
            WHERE StudentID = ?
              AND CAST(CheckInTime AS DATE) = CAST(GETDATE() AS DATE)
        """, student_id)

        existing = cursor.fetchone()

        if existing:
            return False, "Sinh viên đã điểm danh hôm nay."

        # Thêm điểm danh
        cursor.execute("""
            INSERT INTO Attendance
            (
                StudentID,
                CheckInTime,
                Status
            )
            VALUES
            (
                ?,
                GETDATE(),
                N'Có mặt'
            )
        """, student_id)

        conn.commit()

        return True, "Điểm danh thành công."

    except Exception as e:

        conn.rollback()

        return False, f"Lỗi điểm danh: {e}"

    finally:
        conn.close()


# ==========================================================
# LẤY TOÀN BỘ LỊCH SỬ ĐIỂM DANH
# ==========================================================

def get_all_attendance():

    conn = get_connection()

    try:
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                a.AttendanceID,
                a.StudentID,
                s.FullName,
                a.CheckInTime,
                a.Status
            FROM Attendance a
            INNER JOIN Student s
                ON a.StudentID = s.StudentID
            ORDER BY a.CheckInTime DESC
        """)

        return cursor.fetchall()

    finally:
        conn.close()


# ==========================================================
# THỐNG KÊ ĐIỂM DANH
# ==========================================================

def get_attendance_statistics():

    conn = get_connection()

    try:
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                COUNT(*) AS TotalAttendance
            FROM Attendance
        """)

        total = cursor.fetchone()[0]

        cursor.execute("""
            SELECT
                COUNT(DISTINCT StudentID)
            FROM Attendance
        """)

        total_students = cursor.fetchone()[0]

        return total, total_students

    finally:
        conn.close()


# ==========================================================
# TÌM KIẾM ĐIỂM DANH
# ==========================================================

def search_attendance(keyword):

    conn = get_connection()

    try:
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                a.AttendanceID,
                a.StudentID,
                s.FullName,
                a.CheckInTime,
                a.Status
            FROM Attendance a
            INNER JOIN Student s
                ON a.StudentID = s.StudentID
            WHERE
                a.StudentID LIKE ?
                OR s.FullName LIKE ?
            ORDER BY a.CheckInTime DESC
        """,
        f"%{keyword}%",
        f"%{keyword}%"
        )

        return cursor.fetchall()

    finally:
        conn.close()


# ==========================================================
# THỐNG KÊ THEO SINH VIÊN
# ==========================================================

def get_student_statistics(student_id):

    conn = get_connection()

    try:
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                COUNT(*)
            FROM Attendance
            WHERE StudentID = ?
        """, student_id)

        total = cursor.fetchone()[0]

        return total

    finally:
        conn.close()