from flask import Flask, render_template, request, redirect, url_for, jsonify
import cv2
import numpy as np
import base64
import os
import subprocess
import sys
from pathlib import Path

from database import (
    get_all_students,
    get_student,
    add_student,
    update_student,
    delete_student,
    get_all_attendance,
    check_attendance_today,
    add_attendance,
    get_attendance_statistics,
    search_attendance,
    get_student_statistics
)



app = Flask(__name__)

# ==============================
# LOAD FACE MODEL
# ==============================

BASE_DIR = Path(__file__).resolve().parent.parent

MODEL_PATH = BASE_DIR / "models" / "face_model.yml"
LABELS_PATH = BASE_DIR / "models" / "labels.txt"

recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read(str(MODEL_PATH))

labels = {}

with open(LABELS_PATH, "r", encoding="utf-8") as f:
    for line in f:
        line = line.strip()

        if not line:
            continue

        parts = line.split(",")

        if len(parts) == 2:
            label = int(parts[0])
            student_id = parts[1]

            labels[label] = student_id


# ==============================
# API NHẬN DIỆN KHUÔN MẶT
# ==============================

@app.route("/api/recognize", methods=["POST"])
def recognize():

    try:

        data = request.get_json()

        if not data or "image" not in data:
            return jsonify({
                "success": False,
                "message": "Không nhận được hình ảnh"
            })

        image_data = data["image"]

        # Bỏ phần đầu của Base64
        if "," in image_data:
            image_data = image_data.split(",", 1)[1]

        # Chuyển Base64 thành ảnh
        image_bytes = base64.b64decode(image_data)

        image_array = np.frombuffer(
            image_bytes,
            np.uint8
        )

        frame = cv2.imdecode(
            image_array,
            cv2.IMREAD_COLOR
        )

        if frame is None:
            return jsonify({
                "success": False,
                "message": "Không đọc được hình ảnh"
            })

        # Chuyển sang grayscale
        gray = cv2.cvtColor(
            frame,
            cv2.COLOR_BGR2GRAY
        )

        # Haar Cascade
        cascade_path = cv2.data.haarcascades + \
                       "haarcascade_frontalface_default.xml"

        face_cascade = cv2.CascadeClassifier(
            cascade_path
        )

        faces = face_cascade.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=4,
            minSize=(80, 80)
        )

        if len(faces) == 0:

            return jsonify({
                "success": False,
                "message": "Không phát hiện khuôn mặt"
            })

        # Lấy khuôn mặt lớn nhất
        face = max(
            faces,
            key=lambda rect: rect[2] * rect[3]
        )

        x, y, w, h = face

        face_img = gray[
            y:y+h,
            x:x+w
        ]

        # Nhận diện
        label, confidence = recognizer.predict(
            face_img
        )

        # Ngưỡng nhận diện
        if confidence >= 85:

            return jsonify({
                "success": False,
                "message": "Không nhận diện được sinh viên",
                "confidence": round(float(confidence), 2)
            })

        student_id = labels.get(label)

        if student_id is None:

            return jsonify({
                "success": False,
                "message": "Không tìm thấy sinh viên"
            })

        # Kiểm tra sinh viên trong database
        student = get_student(student_id)

        if student is None:

            return jsonify({
                "success": False,
                "message": "Sinh viên không tồn tại trong database"
            })

        # Kiểm tra đã điểm danh hôm nay chưa
        already_attended = check_attendance_today(
            student_id
        )

        if already_attended:

            return jsonify({
                "success": True,
                "student_id": student_id,
                "full_name": student[1],
                "message": "Sinh viên đã điểm danh hôm nay",
                "already_attended": True,
                "confidence": round(float(confidence), 2)
            })

        # Thêm điểm danh
        add_attendance(
            student_id,
            "Present"
        )

        return jsonify({
            "success": True,
            "student_id": student_id,
            "full_name": student[1],
            "message": "Điểm danh thành công!",
            "already_attended": False,
            "confidence": round(float(confidence), 2)
        })

    except Exception as e:

        print("LỖI API:", e)

        return jsonify({
            "success": False,
            "message": str(e)
        })


@app.route("/")
def home():

    students = get_all_students()

    total_students, total_classes, today_attendance = \
        get_student_statistics()

    return render_template(
        "index.html",
        students=students,
        total_students=total_students,
        total_classes=total_classes,
        today_attendance=today_attendance
    )


@app.route("/add", methods=["POST"])
def add():
    student_id = request.form["student_id"]
    full_name = request.form["full_name"]
    gender = request.form["gender"]
    date_of_birth = request.form["date_of_birth"]
    class_id = request.form["class_id"]

    add_student(
        student_id,
        full_name,
        gender,
        date_of_birth,
        class_id
    )

    return redirect(url_for("home"))


@app.route("/edit/<student_id>", methods=["GET", "POST"])
def edit(student_id):

    if request.method == "POST":

        full_name = request.form["full_name"]
        gender = request.form["gender"]
        date_of_birth = request.form["date_of_birth"]
        class_id = request.form["class_id"]

        update_student(
            student_id,
            full_name,
            gender,
            date_of_birth,
            class_id
        )

        return redirect(url_for("home"))

    student = get_student(student_id)

    return render_template(
        "edit.html",
        student=student
    )


@app.route("/delete/<student_id>", methods=["POST"])
def delete(student_id):

    result = delete_student(student_id)

    if not result:
        return """
        <script>
            alert(
                "Không thể xóa sinh viên vì sinh viên đã có dữ liệu điểm danh!"
            );
            window.location.href = "/";
        </script>
        """

    # ==============================
    # XÓA THƯ MỤC KHUÔN MẶT
    # ==============================

    face_folder = BASE_DIR / "dataset" / student_id

    if face_folder.exists():

        import shutil

        shutil.rmtree(face_folder)

    # ==============================
    # TRAIN LẠI MODEL
    # ==============================

    try:

        train_file = BASE_DIR / "src" / "train_model.py"

        subprocess.run(
            [sys.executable, str(train_file)],
            capture_output=True,
            text=True
        )

    except Exception as e:

        print("Lỗi train lại model:", e)

    return redirect(url_for("home"))

@app.route("/face-attendance")
def face_attendance():
    return render_template("face_attendance.html")  

@app.route("/attendance")
def attendance():

    student_id = request.args.get(
        "student_id",
        ""
    )

    if student_id.strip() == "":
        records = get_all_attendance()
    else:
        records = search_attendance(student_id)

    total, total_students, today = get_attendance_statistics()

    return render_template(
        "attendance.html",
        records=records,
        total=total,
        total_students=total_students,
        today=today,
        student_id=student_id
    )
@app.route("/register-face")
def register_face():
    return render_template("register_face.html")


@app.route("/api/register-face", methods=["POST"])
def api_register_face():

    try:

        data = request.get_json()

        student_id = data.get("student_id", "").strip()
        image_data = data.get("image", "")

        if student_id == "":
            return jsonify({
                "success": False,
                "message": "Mã sinh viên không được để trống."
            })

        if image_data == "":
            return jsonify({
                "success": False,
                "message": "Không nhận được hình ảnh."
            })

        # Kiểm tra sinh viên có tồn tại không
        student = get_student(student_id)

        if student is None:

            return jsonify({
                "success": False,
                "message": "Sinh viên không tồn tại."
            })

        # Tạo thư mục dataset
        dataset_folder = BASE_DIR / "dataset" / student_id

        dataset_folder.mkdir(
            parents=True,
            exist_ok=True
        )

        # Bỏ phần đầu Base64
        if "," in image_data:
            image_data = image_data.split(",", 1)[1]

        image_bytes = base64.b64decode(
            image_data
        )

        image_array = np.frombuffer(
            image_bytes,
            np.uint8
        )

        frame = cv2.imdecode(
            image_array,
            cv2.IMREAD_COLOR
        )

        if frame is None:

            return jsonify({
                "success": False,
                "message": "Không đọc được hình ảnh."
            })

        # Lưu số thứ tự ảnh
        existing_images = list(
            dataset_folder.glob("*.jpg")
        )

        image_number = len(existing_images) + 1

        image_path = (
            dataset_folder /
            f"{image_number}.jpg"
        )

        cv2.imwrite(
            str(image_path),
            frame
        )

        return jsonify({
            "success": True,
            "message":
                f"Đã lưu ảnh {image_number} "
                f"cho sinh viên {student_id}."
        })

    except Exception as e:

        print("LỖI ĐĂNG KÝ KHUÔN MẶT:", e)

        return jsonify({
            "success": False,
            "message": str(e)
        })

@app.route("/train-model", methods=["POST"])
def train_model():

    try:

        train_file = BASE_DIR / "src" / "train_model.py"

        result = subprocess.run(
            [sys.executable, str(train_file)],
            capture_output=True,
            text=True
        )

        if result.returncode == 0:

            return jsonify({
                "success": True,
                "message": "Huấn luyện model thành công!"
            })

        return jsonify({
            "success": False,
            "message": "Huấn luyện thất bại: "
                       + result.stderr
        })

    except Exception as e:

        return jsonify({
            "success": False,
            "message": str(e)
        })

if __name__ == "__main__":
    app.run(debug=True)