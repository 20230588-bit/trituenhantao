import cv2
import numpy as np
from pathlib import Path
import sys


# ==========================================
# ĐƯỜNG DẪN PROJECT
# ==========================================

BASE_DIR = Path(__file__).resolve().parent.parent
DATASET_DIR = BASE_DIR / "dataset"
MODELS_DIR = BASE_DIR / "models"

MODELS_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ==========================================
# KIỂM TRA LBPH
# ==========================================

if not hasattr(cv2, "face"):
    print("Khong tim thay cv2.face!")
    print("Hay cai opencv-contrib-python.")
    sys.exit()


# ==========================================
# TẠO LBPH FACE RECOGNIZER
# ==========================================

recognizer = cv2.face.LBPHFaceRecognizer_create()


# ==========================================
# HAAR CASCADE
# ==========================================

cascade_path = (
    cv2.data.haarcascades
    + "haarcascade_frontalface_default.xml"
)

face_cascade = cv2.CascadeClassifier(cascade_path)

if face_cascade.empty():
    print("Khong tai duoc Haar Cascade!")
    sys.exit()


# ==========================================
# KIỂM TRA DATASET
# ==========================================

print("==========================================")
print("       HUAN LUYEN MODEL KHUON MAT")
print("==========================================")
print()

if not DATASET_DIR.exists():
    print("Khong tim thay dataset!")
    sys.exit()


folders = sorted(
    folder
    for folder in DATASET_DIR.iterdir()
    if folder.is_dir()
)

if not folders:
    print("Dataset khong co du lieu!")
    sys.exit()


# ==========================================
# ĐỌC DATASET
# ==========================================

faces = []
labels = []
student_ids = []

label = 0


# ==========================================
# XỬ LÝ TỪNG SINH VIÊN
# ==========================================

for folder in folders:

    student_id = folder.name

    print(
        f"Dang xu ly sinh vien: {student_id}"
    )

    image_files = sorted(
        folder.glob("*.jpg")
    )

    if not image_files:
        print("  WARNING: Khong co anh!")
        print()
        continue

    student_face_count = 0

    for image_path in image_files:

        image = cv2.imread(
            str(image_path)
        )

        if image is None:
            print(
                f"  Khong doc duoc: "
                f"{image_path.name}"
            )
            continue

        gray = cv2.cvtColor(
            image,
            cv2.COLOR_BGR2GRAY
        )

        detected_faces = face_cascade.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=4,
            minSize=(80, 80)
        )

        if len(detected_faces) == 0:

            print(
                f"  Khong tim thay mat: "
                f"{image_path.name}"
            )

            continue

        # Chọn khuôn mặt lớn nhất
        x, y, w, h = max(
            detected_faces,
            key=lambda face: face[2] * face[3]
        )

        face_image = gray[
            y:y + h,
            x:x + w
        ]

        faces.append(face_image)
        labels.append(label)

        student_face_count += 1

    print(
        f"  Anh hop le: "
        f"{student_face_count}"
    )

    # Chỉ thêm sinh viên nếu có ảnh hợp lệ
    if student_face_count > 0:

        student_ids.append(student_id)
        label += 1

    print()


# ==========================================
# KIỂM TRA DỮ LIỆU
# ==========================================

if len(faces) == 0:

    print(
        "Khong co anh hop le "
        "de huan luyen!"
    )

    sys.exit()


print("==========================================")
print(
    f"Tong anh dung de huan luyen: "
    f"{len(faces)}"
)
print(
    f"So sinh vien: "
    f"{len(student_ids)}"
)
print("==========================================")
print()


# ==========================================
# HUẤN LUYỆN MODEL
# ==========================================

print("Dang huan luyen model...")
print("Vui long cho trong giay lat...")
print()

recognizer.train(
    faces,
    np.array(labels)
)


# ==========================================
# LƯU MODEL
# ==========================================

model_path = (
    MODELS_DIR / "face_model.yml"
)

recognizer.write(
    str(model_path)
)


# ==========================================
# LƯU DANH SÁCH LABEL
# ==========================================

labels_path = (
    MODELS_DIR / "labels.txt"
)

with open(
    labels_path,
    "w",
    encoding="utf-8"
) as file:

    for label, student_id in enumerate(
        student_ids
    ):

        file.write(
            f"{label},{student_id}\n"
        )


# ==========================================
# HOÀN THÀNH
# ==========================================

print()
print("==========================================")
print("       HUAN LUYEN THANH CONG!")
print("==========================================")

print(
    f"Model: {model_path}"
)

print(
    f"Labels: {labels_path}"
)

print()