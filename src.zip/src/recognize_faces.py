import cv2
from pathlib import Path
import sys
import time

from attendance import add_attendance


# ==========================================================
# ĐƯỜNG DẪN PROJECT
# ==========================================================

BASE_DIR = Path(__file__).resolve().parent.parent
MODELS_DIR = BASE_DIR / "models"


# ==========================================================
# NHẬN DIỆN KHUÔN MẶT
# ==========================================================

def recognize_faces():

    # ======================================================
    # KIỂM TRA MODEL
    # ======================================================

    model_path = MODELS_DIR / "face_model.yml"
    labels_path = MODELS_DIR / "labels.txt"

    if not model_path.exists():

        return (
            False,
            "Không tìm thấy face_model.yml!\n"
            "Hãy huấn luyện model trước."
        )

    if not labels_path.exists():

        return (
            False,
            "Không tìm thấy labels.txt!"
        )

    # ======================================================
    # ĐỌC LABEL
    # ======================================================

    labels = {}

    try:

        with open(
            labels_path,
            "r",
            encoding="utf-8"
        ) as file:

            for line in file:

                line = line.strip()

                if not line:
                    continue

                parts = line.split(",")

                if len(parts) != 2:
                    continue

                label = int(parts[0])
                student_id = parts[1]

                labels[label] = student_id

    except Exception as e:

        return (
            False,
            f"Không thể đọc labels.txt:\n{e}"
        )

    if not labels:

        return (
            False,
            "Không có dữ liệu sinh viên trong labels.txt!"
        )

    # ======================================================
    # KIỂM TRA CV2 FACE
    # ======================================================

    if not hasattr(cv2, "face"):

        return (
            False,
            "Không tìm thấy cv2.face!\n"
            "Hãy cài opencv-contrib-python."
        )

    # ======================================================
    # LOAD LBPH MODEL
    # ======================================================

    try:

        recognizer = (
            cv2.face.LBPHFaceRecognizer_create()
        )

        recognizer.read(
            str(model_path)
        )

    except Exception as e:

        return (
            False,
            f"Không thể tải model:\n{e}"
        )

    # ======================================================
    # LOAD HAAR CASCADE
    # ======================================================

    cascade_path = (
        cv2.data.haarcascades
        + "haarcascade_frontalface_default.xml"
    )

    face_cascade = cv2.CascadeClassifier(
        cascade_path
    )

    if face_cascade.empty():

        return (
            False,
            "Không thể tải Haar Cascade!"
        )

    # ======================================================
    # MỞ CAMERA
    # ======================================================

    camera = cv2.VideoCapture(0)

    if not camera.isOpened():

        return (
            False,
            "Không mở được camera!"
        )

    # ======================================================
    # BIẾN ĐIỂM DANH
    # ======================================================

    recognized_student = None
    recognized_confidence = None

    attendance_message = ""

    last_attendance_time = 0

    # Thời gian tối thiểu giữa 2 lần xử lý
    attendance_delay = 3

    # ======================================================
    # CAMERA LOOP
    # ======================================================

    while True:

        ret, frame = camera.read()

        if not ret:

            attendance_message = (
                "Không đọc được camera!"
            )

            break

        # --------------------------------------------------
        # LẬT CAMERA
        # --------------------------------------------------

        frame = cv2.flip(
            frame,
            1
        )

        # --------------------------------------------------
        # GRAYSCALE
        # --------------------------------------------------

        gray = cv2.cvtColor(
            frame,
            cv2.COLOR_BGR2GRAY
        )

        gray = cv2.equalizeHist(
            gray
        )

        # --------------------------------------------------
        # PHÁT HIỆN KHUÔN MẶT
        # --------------------------------------------------

        faces = face_cascade.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=4,
            minSize=(80, 80)
        )

        # ==================================================
        # NHẬN DIỆN
        # ==================================================

        for (
            x,
            y,
            w,
            h
        ) in faces:

            face_image = gray[
                y:y + h,
                x:x + w
            ]

            try:

                label, confidence = (
                    recognizer.predict(
                        face_image
                    )
                )

            except Exception:

                continue

            # --------------------------------------------------
            # LBPH
            # confidence càng thấp càng tốt
            # --------------------------------------------------

            if confidence < 80:

                student_id = labels.get(
                    label,
                    "Unknown"
                )

                if student_id != "Unknown":

                    recognized_student = student_id
                    recognized_confidence = confidence

                    display_text = (
                        f"{student_id} "
                        f"({confidence:.1f})"
                    )

                    # ==========================================
                    # TỰ ĐỘNG ĐIỂM DANH
                    # ==========================================

                    current_time = time.time()

                    if (
                        current_time
                        - last_attendance_time
                        >= attendance_delay
                    ):

                        success, message = (
                            add_attendance(
                                student_id
                            )
                        )

                        attendance_message = message

                        last_attendance_time = (
                            current_time
                        )

                        if success:

                            print(
                                f"[DIEM DANH] "
                                f"{student_id}: "
                                f"{message}"
                            )

                        else:

                            print(
                                f"[THONG BAO] "
                                f"{student_id}: "
                                f"{message}"
                            )

                else:

                    display_text = (
                        f"Unknown "
                        f"({confidence:.1f})"
                    )

            else:

                display_text = (
                    f"Unknown "
                    f"({confidence:.1f})"
                )

            # ==================================================
            # VẼ KHUNG KHUÔN MẶT
            # ==================================================

            cv2.rectangle(
                frame,
                (x, y),
                (x + w, y + h),
                (0, 255, 0),
                2
            )

            # ==================================================
            # HIỂN THỊ KẾT QUẢ
            # ==================================================

            cv2.putText(
                frame,
                display_text,
                (x, y - 10),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (0, 255, 0),
                2
            )

        # ==================================================
        # HIỂN THỊ TRẠNG THÁI ĐIỂM DANH
        # ==================================================

        if attendance_message:

            cv2.putText(
                frame,
                attendance_message,
                (20, 70),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 0),
                2
            )

        # ==================================================
        # HƯỚNG DẪN
        # ==================================================

        cv2.putText(
            frame,
            "Nhan Q de thoat",
            (20, 35),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 255),
            2
        )

        # ==================================================
        # HIỂN THỊ CAMERA
        # ==================================================

        cv2.imshow(
            "Face Recognition",
            frame
        )

        # ==================================================
        # PHÍM Q
        # ==================================================

        key = cv2.waitKey(1) & 0xFF

        if key == ord("q"):

            break

    # ======================================================
    # ĐÓNG CAMERA
    # ======================================================

    camera.release()

    cv2.destroyAllWindows()

    # ======================================================
    # KẾT QUẢ
    # ======================================================

    if recognized_student:

        if attendance_message:

            return (
                True,
                f"Sinh viên: {recognized_student}\n"
                f"Confidence: "
                f"{recognized_confidence:.1f}\n\n"
                f"{attendance_message}"
            )

        return (
            True,
            f"Đã nhận diện sinh viên "
            f"{recognized_student}."
        )

    return (
        False,
        "Không nhận diện được sinh viên."
    )


# ==========================================================
# CHẠY ĐỘC LẬP
# ==========================================================

if __name__ == "__main__":

    success, message = recognize_faces()

    print()
    print("=" * 50)
    print(message)
    print("=" * 50)