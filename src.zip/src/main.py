import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime

from capture_faces import capture_faces
from recognize_faces import recognize_faces
from database import (
    get_all_students,
    get_dashboard_statistics,
    add_student,
    update_student,
    delete_student
)

from attendance import get_all_attendance

# ==========================================================
# ỨNG DỤNG ĐIỂM DANH KHUÔN MẶT
# ==========================================================

class FaceAttendanceApp:

    def __init__(self, root):

        self.root = root

        self.root.title(
            "Hệ thống điểm danh sinh viên bằng khuôn mặt"
        )

        self.root.geometry("1200x700")
        self.root.minsize(1000, 600)

        # Màu giao diện
        self.sidebar_color = "#1f2a38"
        self.main_color = "#f4f6f8"

        # Tạo giao diện
        self.create_sidebar()
        self.create_main_area()

        # Trang mặc định
        self.show_home()

    # ======================================================
    # SIDEBAR
    # ======================================================

    def create_sidebar(self):

        self.sidebar = tk.Frame(
            self.root,
            bg=self.sidebar_color,
            width=270
        )

        self.sidebar.pack(
            side="left",
            fill="y"
        )

        self.sidebar.pack_propagate(False)

        # Tiêu đề
        tk.Label(
            self.sidebar,
            text="FACE ATTENDANCE",
            bg=self.sidebar_color,
            fg="white",
            font=("Arial", 18, "bold")
        ).pack(
            pady=(30, 5)
        )

        tk.Label(
            self.sidebar,
            text="QUẢN LÝ ĐIỂM DANH",
            bg=self.sidebar_color,
            fg="#bdc3c7",
            font=("Arial", 10)
        ).pack(
            pady=(0, 30)
        )

        # ==================================================
        # CÁC NÚT MENU
        # ==================================================

        self.create_menu_button(
            "🏠  Trang chủ",
            self.show_home
        )

        self.create_menu_button(
            "👨‍🎓  Quản lý sinh viên",
            self.show_students
        )

        self.create_menu_button(
            "📷  Đăng ký khuôn mặt",
            self.show_capture
        )

        self.create_menu_button(
            "🤖  Nhận diện & điểm danh",
            self.show_attendance
        )

        self.create_menu_button(
            "📋  Lịch sử điểm danh",
            self.show_history
        )

        self.create_menu_button(
            "⚙  Huấn luyện mô hình",
            self.show_training
        )

        # ==================================================
        # NÚT THOÁT
        # ==================================================

        tk.Button(
            self.sidebar,
            text="🚪  Thoát chương trình",
            command=self.exit_app,
            bg="#c0392b",
            fg="white",
            activebackground="#e74c3c",
            activeforeground="white",
            relief="flat",
            bd=0,
            font=("Arial", 11, "bold"),
            anchor="w",
            padx=20,
            cursor="hand2"
        ).pack(
            side="bottom",
            fill="x",
            padx=15,
            pady=20,
            ipady=10
        )

    # ======================================================
    # TẠO NÚT MENU
    # ======================================================

    def create_menu_button(
        self,
        text,
        command
    ):

        tk.Button(
            self.sidebar,
            text=text,
            command=command,
            bg=self.sidebar_color,
            fg="white",
            activebackground="#34495e",
            activeforeground="white",
            relief="flat",
            bd=0,
            font=("Arial", 11),
            anchor="w",
            padx=20,
            cursor="hand2"
        ).pack(
            fill="x",
            padx=15,
            pady=3,
            ipady=10
        )

    # ======================================================
    # KHU VỰC MAIN
    # ======================================================

    def create_main_area(self):

        self.main_frame = tk.Frame(
            self.root,
            bg=self.main_color
        )

        self.main_frame.pack(
            side="right",
            fill="both",
            expand=True
        )

    # ======================================================
    # XÓA MAIN
    # ======================================================

    def clear_main(self):

        for widget in self.main_frame.winfo_children():
            widget.destroy()

    # ======================================================
    # TRANG CHỦ
    # ======================================================

    def show_home(self):

       self.clear_main()

    # ==================================================
    # TIÊU ĐỀ
    # ==================================================

       tk.Label(
        self.main_frame,
        text="Trang chủ",
        bg=self.main_color,
        fg="#1f2a38",
        font=("Arial", 26, "bold")
        ).pack(
        anchor="w",
        padx=30,
        pady=(25, 5)
       )

       tk.Label(
        self.main_frame,
        text="Tổng quan hệ thống điểm danh",
        bg=self.main_color,
        fg="#666666",
        font=("Arial", 12)
       ).pack(
          anchor="w",
           padx=30
        )

    # ==================================================
    # KHUNG THỐNG KÊ
    # ==================================================

       statistics_frame = tk.Frame(
        self.main_frame,
        bg=self.main_color
        )

       statistics_frame.pack(
        fill="x",
        padx=30,
        pady=30
        )

    # --------------------------------------------------
    # CARD 1
    # --------------------------------------------------

       self.total_students_card = self.create_stat_card(
        statistics_frame,
        "👨‍🎓",
        "Tổng sinh viên",
        "0"
       )

       self.total_students_card.grid(
        row=0,
        column=0,
        padx=10,
        sticky="nsew"
       )

    # --------------------------------------------------
    # CARD 2
    # --------------------------------------------------

       self.attended_card = self.create_stat_card(
        statistics_frame,
        "✅",
        "Đã điểm danh hôm nay",
        "0"
        )

       self.attended_card.grid(
        row=0,
        column=1,
        padx=10,
        sticky="nsew"
       )

    # --------------------------------------------------
    # CARD 3
    # --------------------------------------------------

       self.not_attended_card = self.create_stat_card(
        statistics_frame,
        "⏳",
        "Chưa điểm danh",
        "0"
       )

       self.not_attended_card.grid(
         row=0,
        column=2,
        padx=10,
        sticky="nsew"
        )

    # --------------------------------------------------
    # CARD 4
    # --------------------------------------------------

       self.attendance_today_card = self.create_stat_card(
        statistics_frame,
        "📋",
        "Lượt điểm danh hôm nay",
        "0"
       )

       self.attendance_today_card.grid(
        row=0,
        column=3,
        padx=10,
        sticky="nsew"
       )

       for i in range(4):
 
        statistics_frame.columnconfigure(
            i,
            weight=1
        )

    # ==================================================
    # KHU VỰC HƯỚNG DẪN
    # ==================================================

       content = tk.Frame(
        self.main_frame,
        bg="white"
       )

       content.pack(
        fill="both",
        expand=True,
        padx=30,
        pady=(0, 30)
       )

       tk.Label(
        content,
        text="Quy trình sử dụng hệ thống",
        bg="white",
        fg="#1f2a38",
        font=("Arial", 19, "bold")
        ).pack(
        anchor="w",
        padx=30,
        pady=(25, 15)
       )

       steps = (
        "1. 👨‍🎓 Quản lý sinh viên\n"
        "   Thêm thông tin sinh viên vào hệ thống.\n\n"

        "2. 📷 Đăng ký khuôn mặt\n"
        "   Chụp dữ liệu khuôn mặt cho sinh viên.\n\n"

        "3. ⚙ Huấn luyện mô hình\n"
        "   Sử dụng dữ liệu khuôn mặt để huấn luyện LBPH.\n\n"

        "4. 🤖 Nhận diện & điểm danh\n"
        "   Camera nhận diện và tự động ghi điểm danh.\n\n"

        "5. 📋 Lịch sử điểm danh\n"
        "   Kiểm tra các lần điểm danh đã lưu."
       )

       tk.Label(
        content,
        text=steps,
        bg="white",
        fg="#555555",
        font=("Arial", 11),
        justify="left"
       ).pack(
        anchor="w",
        padx=40
       )

    # ==================================================
    # NÚT LÀM MỚI
    # ==================================================

       tk.Button(
        content,
        text="🔄 Cập nhật thống kê",
        command=self.load_dashboard_statistics,
        bg="#2980b9",
        fg="white",
        font=("Arial", 11, "bold"),
        width=20,
        cursor="hand2"
       ).pack(
        anchor="w",
        padx=40,
        pady=25
       )

    # ==================================================
    # LOAD DỮ LIỆU
    # ==================================================

       self.load_dashboard_statistics()

    # ======================================================
    # QUẢN LÝ SINH VIÊN
    # ======================================================
    def create_stat_card(self, parent, icon, title, value):

        card = tk.Frame(
            parent,
            bg="white",
            height=140,
            bd=1,
            relief="solid"
        )
        card.grid_propagate(False)

        tk.Label(
            card,
            text=icon,
            bg="white",
            font=("Arial", 25)
        ).pack(pady=(15, 2))

        tk.Label(
            card,
            text=title,
            bg="white",
            fg="#666666",
            font=("Arial", 10, "bold")
        ).pack()

        value_label = tk.Label(
            card,
            text=value,
            bg="white",
            fg="#1f2a38",
            font=("Arial", 22, "bold")
        )
        value_label.pack(pady=5)

        card.value_label = value_label
        return card

    def load_dashboard_statistics(self):

        try:
            total_students, attended_today, not_attended_today, attendance_today = (
                get_dashboard_statistics()
            )

            self.total_students_card.value_label.config(
                text=str(total_students)
            )
            self.attended_card.value_label.config(
                text=str(attended_today)
            )
            self.not_attended_card.value_label.config(
                text=str(not_attended_today)
            )
            self.attendance_today_card.value_label.config(
                text=str(attendance_today)
            )

        except Exception as e:
            messagebox.showerror(
                "Lỗi",
                f"Không thể tải thống kê:\\n{e}"
            )

    def show_students(self):

        self.clear_main()

        tk.Label(
            self.main_frame,
            text="Quản lý sinh viên",
            bg=self.main_color,
            fg="#1f2a38",
            font=("Arial", 24, "bold")
        ).pack(
            anchor="w",
            padx=30,
            pady=(25, 15)
        )

        # ==================================================
        # FORM
        # ==================================================

        form = tk.Frame(
            self.main_frame,
            bg="white"
        )

        form.pack(
            fill="x",
            padx=30,
            pady=5
        )

        # Mã sinh viên
        tk.Label(
            form,
            text="Mã sinh viên:",
            bg="white",
            font=("Arial", 10, "bold")
        ).grid(
            row=0,
            column=0,
            padx=10,
            pady=10,
            sticky="w"
        )

        self.txt_student_id = tk.Entry(
            form,
            width=25
        )

        self.txt_student_id.grid(
            row=0,
            column=1,
            padx=10,
            pady=10
        )

        # Họ tên
        tk.Label(
            form,
            text="Họ tên:",
            bg="white",
            font=("Arial", 10, "bold")
        ).grid(
            row=0,
            column=2,
            padx=10,
            pady=10,
            sticky="w"
        )

        self.txt_full_name = tk.Entry(
            form,
            width=30
        )

        self.txt_full_name.grid(
            row=0,
            column=3,
            padx=10,
            pady=10
        )

        # Giới tính
        tk.Label(
            form,
            text="Giới tính:",
            bg="white",
            font=("Arial", 10, "bold")
        ).grid(
            row=1,
            column=0,
            padx=10,
            pady=10,
            sticky="w"
        )

        self.cbo_gender = ttk.Combobox(
            form,
            values=[
                "Nam",
                "Nữ"
            ],
            width=22,
            state="readonly"
        )

        self.cbo_gender.grid(
            row=1,
            column=1,
            padx=10,
            pady=10
        )

        self.cbo_gender.set("Nam")

        # Ngày sinh
        tk.Label(
            form,
            text="Ngày sinh:",
            bg="white",
            font=("Arial", 10, "bold")
        ).grid(
            row=1,
            column=2,
            padx=10,
            pady=10,
            sticky="w"
        )

        self.txt_date = tk.Entry(
            form,
            width=30
        )

        self.txt_date.grid(
            row=1,
            column=3,
            padx=10,
            pady=10
        )

        # Mã lớp
        tk.Label(
            form,
            text="Mã lớp:",
            bg="white",
            font=("Arial", 10, "bold")
        ).grid(
            row=2,
            column=0,
            padx=10,
            pady=10,
            sticky="w"
        )

        self.txt_class_id = tk.Entry(
            form,
            width=25
        )

        self.txt_class_id.grid(
            row=2,
            column=1,
            padx=10,
            pady=10
        )

        # ==================================================
        # BUTTON
        # ==================================================

        button_frame = tk.Frame(
            form,
            bg="white"
        )

        button_frame.grid(
            row=2,
            column=2,
            columnspan=2,
            pady=10
        )

        tk.Button(
            button_frame,
            text="Thêm",
            command=self.add_student_action,
            bg="#27ae60",
            fg="white",
            width=10,
            cursor="hand2"
        ).pack(
            side="left",
            padx=5
        )

        tk.Button(
            button_frame,
            text="Sửa",
            command=self.update_student_action,
            bg="#2980b9",
            fg="white",
            width=10,
            cursor="hand2"
        ).pack(
            side="left",
            padx=5
        )

        tk.Button(
            button_frame,
            text="Xóa",
            command=self.delete_student_action,
            bg="#c0392b",
            fg="white",
            width=10,
            cursor="hand2"
        ).pack(
            side="left",
            padx=5
        )

        tk.Button(
            button_frame,
            text="Làm mới",
            command=self.clear_student_form,
            bg="#7f8c8d",
            fg="white",
            width=10,
            cursor="hand2"
        ).pack(
            side="left",
            padx=5
        )

        # ==================================================
        # TABLE
        # ==================================================

        table_frame = tk.Frame(
            self.main_frame,
            bg="white"
        )

        table_frame.pack(
            fill="both",
            expand=True,
            padx=30,
            pady=15
        )

        columns = (
            "StudentID",
            "FullName",
            "Gender",
            "DateOfBirth",
            "ClassID",
            "FaceFolder"
        )

        self.student_table = ttk.Treeview(
            table_frame,
            columns=columns,
            show="headings"
        )

        headings = {
            "StudentID": "Mã SV",
            "FullName": "Họ tên",
            "Gender": "Giới tính",
            "DateOfBirth": "Ngày sinh",
            "ClassID": "Mã lớp",
            "FaceFolder": "Thư mục khuôn mặt"
        }

        widths = {
            "StudentID": 100,
            "FullName": 200,
            "Gender": 80,
            "DateOfBirth": 120,
            "ClassID": 100,
            "FaceFolder": 180
        }

        for column in columns:

            self.student_table.heading(
                column,
                text=headings[column]
            )

            self.student_table.column(
                column,
                width=widths[column]
            )

        scrollbar = ttk.Scrollbar(
            table_frame,
            orient="vertical",
            command=self.student_table.yview
        )

        self.student_table.configure(
            yscrollcommand=scrollbar.set
        )

        self.student_table.pack(
            side="left",
            fill="both",
            expand=True
        )

        scrollbar.pack(
            side="right",
            fill="y"
        )

        self.student_table.bind(
            "<<TreeviewSelect>>",
            self.select_student
        )

        self.load_students()

    # ======================================================
    # LOAD SINH VIÊN
    # ======================================================

    def load_students(self):

        try:

            for item in self.student_table.get_children():

                self.student_table.delete(item)

            students = get_all_students()

            for student in students:

                values = tuple(student)

                student_id = (
                    values[0]
                    if len(values) > 0
                    else ""
                )

                full_name = (
                    values[1]
                    if len(values) > 1
                    else ""
                )

                gender = (
                    values[2]
                    if len(values) > 2
                    else ""
                )

                date_of_birth = (
                    values[3]
                    if len(values) > 3
                    else ""
                )

                class_id = (
                    values[4]
                    if len(values) > 4
                    else ""
                )

                face_folder = (
                    values[5]
                    if len(values) > 5
                    else ""
                )

                if hasattr(
                    date_of_birth,
                    "strftime"
                ):

                    date_of_birth = (
                        date_of_birth.strftime(
                            "%Y-%m-%d"
                        )
                    )

                self.student_table.insert(
                    "",
                    "end",
                    values=(
                        student_id,
                        full_name,
                        gender,
                        date_of_birth,
                        class_id,
                        face_folder
                    )
                )

        except Exception as e:

            messagebox.showerror(
                "Lỗi",
                f"Không thể tải danh sách sinh viên:\n{e}"
            )

    # ======================================================
    # CHỌN SINH VIÊN
    # ======================================================

    def select_student(self, event=None):

        selected = self.student_table.selection()

        if not selected:
            return

        values = self.student_table.item(
            selected[0],
            "values"
        )

        if not values:
            return

        self.txt_student_id.delete(
            0,
            tk.END
        )

        self.txt_student_id.insert(
            0,
            values[0]
        )

        self.txt_full_name.delete(
            0,
            tk.END
        )

        self.txt_full_name.insert(
            0,
            values[1]
        )

        self.cbo_gender.set(
            values[2]
        )

        self.txt_date.delete(
            0,
            tk.END
        )

        self.txt_date.insert(
            0,
            values[3]
        )

        self.txt_class_id.delete(
            0,
            tk.END
        )

        self.txt_class_id.insert(
            0,
            values[4]
        )

    # ======================================================
    # THÊM SINH VIÊN
    # ======================================================

    def add_student_action(self):

        student_id = (
            self.txt_student_id
            .get()
            .strip()
        )

        full_name = (
            self.txt_full_name
            .get()
            .strip()
        )

        gender = (
            self.cbo_gender
            .get()
            .strip()
        )

        date_text = (
            self.txt_date
            .get()
            .strip()
        )

        class_id = (
            self.txt_class_id
            .get()
            .strip()
        )

        if not student_id:

            messagebox.showwarning(
                "Thiếu thông tin",
                "Vui lòng nhập mã sinh viên."
            )

            return

        if not full_name:

            messagebox.showwarning(
                "Thiếu thông tin",
                "Vui lòng nhập họ tên."
            )

            return

        date_of_birth = None

        if date_text:

            try:

                date_of_birth = datetime.strptime(
                    date_text,
                    "%Y-%m-%d"
                ).date()

            except ValueError:

                messagebox.showerror(
                    "Ngày sinh không hợp lệ",
                    "Vui lòng nhập ngày sinh theo dạng:\n"
                    "YYYY-MM-DD\n\n"
                    "Ví dụ: 2004-01-15"
                )

                return

        try:

            students = get_all_students()

            for student in students:

                if str(student[0]) == student_id:

                    messagebox.showwarning(
                        "Trùng mã sinh viên",
                        f"Mã sinh viên {student_id} đã tồn tại."
                    )

                    return

            add_student(
                student_id,
                full_name,
                gender,
                date_of_birth,
                class_id if class_id else None
            )

            messagebox.showinfo(
                "Thành công",
                "Đã thêm sinh viên."
            )

            self.load_students()
            self.clear_student_form()

        except Exception as e:

            messagebox.showerror(
                "Lỗi",
                f"Không thể thêm sinh viên:\n{e}"
            )

    # ======================================================
    # SỬA SINH VIÊN
    # ======================================================

    def update_student_action(self):

        student_id = (
            self.txt_student_id
            .get()
            .strip()
        )

        full_name = (
            self.txt_full_name
            .get()
            .strip()
        )

        gender = (
            self.cbo_gender
            .get()
            .strip()
        )

        date_text = (
            self.txt_date
            .get()
            .strip()
        )

        class_id = (
            self.txt_class_id
            .get()
            .strip()
        )

        if not student_id:

            messagebox.showwarning(
                "Thông báo",
                "Vui lòng chọn sinh viên cần sửa."
            )

            return

        if not full_name:

            messagebox.showwarning(
                "Thông báo",
                "Vui lòng nhập họ tên."
            )

            return

        date_of_birth = None

        if date_text:

            try:

                date_of_birth = datetime.strptime(
                    date_text,
                    "%Y-%m-%d"
                ).date()

            except ValueError:

                messagebox.showerror(
                    "Ngày sinh không hợp lệ",
                    "Vui lòng nhập ngày sinh theo dạng:\n"
                    "YYYY-MM-DD"
                )

                return

        try:

            update_student(
                student_id,
                full_name,
                gender,
                date_of_birth,
                class_id if class_id else None
            )

            messagebox.showinfo(
                "Thành công",
                "Đã cập nhật sinh viên."
            )

            self.load_students()
            self.clear_student_form()

        except Exception as e:

            messagebox.showerror(
                "Lỗi",
                f"Không thể cập nhật sinh viên:\n{e}"
            )

    # ======================================================
    # XÓA SINH VIÊN
    # ======================================================

    def delete_student_action(self):

        student_id = (
            self.txt_student_id
            .get()
            .strip()
        )

        if not student_id:

            messagebox.showwarning(
                "Thông báo",
                "Vui lòng chọn sinh viên cần xóa."
            )

            return

        confirm = messagebox.askyesno(
            "Xác nhận",
            f"Bạn có chắc muốn xóa sinh viên {student_id}?"
        )

        if not confirm:
            return

        try:

            delete_student(
                student_id
            )

            messagebox.showinfo(
                "Thành công",
                "Đã xóa sinh viên."
            )

            self.load_students()
            self.clear_student_form()

        except Exception as e:

            messagebox.showerror(
                "Lỗi",
                f"Không thể xóa sinh viên:\n{e}"
            )

    # ======================================================
    # LÀM MỚI FORM
    # ======================================================

    def clear_student_form(self):

        self.txt_student_id.delete(
            0,
            tk.END
        )

        self.txt_full_name.delete(
            0,
            tk.END
        )

        self.cbo_gender.set(
            "Nam"
        )

        self.txt_date.delete(
            0,
            tk.END
        )

        self.txt_class_id.delete(
            0,
            tk.END
        )

    # ======================================================
    # ĐĂNG KÝ KHUÔN MẶT
    # ======================================================

    def show_capture(self):

        self.clear_main()

        tk.Label(
            self.main_frame,
            text="Đăng ký khuôn mặt",
            bg=self.main_color,
            fg="#1f2a38",
            font=("Arial", 24, "bold")
        ).pack(
            anchor="w",
            padx=30,
            pady=(30, 10)
        )

        tk.Label(
            self.main_frame,
            text="Đăng ký dữ liệu khuôn mặt cho sinh viên",
            bg=self.main_color,
            fg="#666666",
            font=("Arial", 12)
        ).pack(
            anchor="w",
            padx=30,
            pady=(0, 20)
        )

        form = tk.Frame(
            self.main_frame,
            bg="white"
        )

        form.pack(
            fill="x",
            padx=30,
            pady=10
        )

        tk.Label(
            form,
            text="Mã sinh viên:",
            bg="white",
            font=("Arial", 11, "bold")
        ).grid(
            row=0,
            column=0,
            padx=20,
            pady=20
        )

        self.capture_student_id = tk.Entry(
            form,
            width=25,
            font=("Arial", 11)
        )

        self.capture_student_id.grid(
            row=0,
            column=1,
            padx=10,
            pady=20
        )

        tk.Button(
            form,
            text="📷 Bắt đầu chụp",
            command=self.start_capture,
            bg="#27ae60",
            fg="white",
            font=("Arial", 11, "bold"),
            width=18,
            cursor="hand2"
        ).grid(
            row=0,
            column=2,
            padx=20,
            pady=20
        )

        guide = tk.Frame(
            self.main_frame,
            bg="white"
        )

        guide.pack(
            fill="both",
            expand=True,
            padx=30,
            pady=15
        )

        tk.Label(
            guide,
            text="Hướng dẫn đăng ký",
            bg="white",
            fg="#1f2a38",
            font=("Arial", 18, "bold")
        ).pack(
            pady=(35, 20)
        )

        instructions = (
            "1. Nhập mã sinh viên đã tồn tại trong hệ thống.\n\n"
            "2. Nhấn 'Bắt đầu chụp'.\n\n"
            "3. Đưa khuôn mặt vào giữa camera.\n\n"
            "4. Giữ khuôn mặt ổn định để chương trình tự động chụp.\n\n"
            "5. Nhấn phím Q để kết thúc."
        )

        tk.Label(
            guide,
            text=instructions,
            bg="white",
            fg="#555555",
            font=("Arial", 12),
            justify="left"
        ).pack(
            anchor="w",
            padx=80
        )

    # ======================================================
    # BẮT ĐẦU CHỤP
    # ======================================================

    def start_capture(self):

        student_id = (
            self.capture_student_id
            .get()
            .strip()
        )

        if not student_id:

            messagebox.showwarning(
                "Thiếu thông tin",
                "Vui lòng nhập mã sinh viên."
            )

            return

        try:

            students = get_all_students()

            student_exists = False

            for student in students:

                if str(student[0]) == student_id:

                    student_exists = True
                    break

            if not student_exists:

                messagebox.showerror(
                    "Không tìm thấy sinh viên",
                    f"Mã sinh viên {student_id} chưa tồn tại."
                )

                return

        except Exception as e:

            messagebox.showerror(
                "Lỗi",
                f"Không thể kiểm tra sinh viên:\n{e}"
            )

            return

        confirm = messagebox.askyesno(
            "Đăng ký khuôn mặt",
            f"Bắt đầu chụp khuôn mặt cho sinh viên {student_id}?"
        )

        if not confirm:
            return

        try:

            success, message = capture_faces(
                student_id
            )

            if success:

                messagebox.showinfo(
                    "Hoàn tất",
                    message
                )

            else:

                messagebox.showwarning(
                    "Chưa hoàn tất",
                    message
                )

        except Exception as e:

            messagebox.showerror(
                "Lỗi",
                f"Không thể đăng ký khuôn mặt:\n{e}"
            )

    # ======================================================
    # NHẬN DIỆN & ĐIỂM DANH
    # ======================================================

    def show_attendance(self):

        self.clear_main()

        tk.Label(
            self.main_frame,
            text="Nhận diện & điểm danh",
            bg=self.main_color,
            fg="#1f2a38",
            font=("Arial", 24, "bold")
        ).pack(
            anchor="w",
            padx=30,
            pady=(30, 10)
        )

        tk.Label(
            self.main_frame,
            text="Nhận diện sinh viên bằng camera",
            bg=self.main_color,
            fg="#666666",
            font=("Arial", 12)
        ).pack(
            anchor="w",
            padx=30,
            pady=(0, 20)
        )

        frame = tk.Frame(
            self.main_frame,
            bg="white"
        )

        frame.pack(
            fill="x",
            padx=30,
            pady=20
        )

        tk.Label(
            frame,
            text="🤖 Nhận diện khuôn mặt",
            bg="white",
            fg="#1f2a38",
            font=("Arial", 18, "bold")
        ).pack(
            pady=(30, 15)
        )

        tk.Label(
            frame,
            text=(
                "Đưa khuôn mặt vào camera để hệ thống "
                "nhận diện sinh viên."
            ),
            bg="white",
            fg="#555555",
            font=("Arial", 12)
        ).pack(
            pady=10
        )

        tk.Button(
            frame,
            text="🎯 Bắt đầu nhận diện",
            command=self.start_recognition,
            bg="#2980b9",
            fg="white",
            font=("Arial", 12, "bold"),
            width=24,
            height=2,
            cursor="hand2"
        ).pack(
            pady=(15, 30)
        )

        guide = tk.Frame(
            self.main_frame,
            bg="white"
        )

        guide.pack(
            fill="both",
            expand=True,
            padx=30,
            pady=10
        )

        tk.Label(
            guide,
            text="Hướng dẫn",
            bg="white",
            fg="#1f2a38",
            font=("Arial", 18, "bold")
        ).pack(
            pady=(25, 15)
        )

        instructions = (
            "1. Nhấn 'Bắt đầu nhận diện'.\n\n"
            "2. Đưa khuôn mặt đã đăng ký vào camera.\n\n"
            "3. Hệ thống sẽ so sánh với model LBPH.\n\n"
            "4. Mã sinh viên sẽ hiển thị nếu nhận diện được.\n\n"
            "5. Nhấn Q để đóng camera."
        )

        tk.Label(
            guide,
            text=instructions,
            bg="white",
            fg="#555555",
            font=("Arial", 12),
            justify="left"
        ).pack(
            anchor="w",
            padx=80
        )

    # ======================================================
    # BẮT ĐẦU NHẬN DIỆN
    # ======================================================

    def start_recognition(self):

        confirm = messagebox.askyesno(
            "Nhận diện khuôn mặt",
            "Bạn có muốn bắt đầu nhận diện khuôn mặt?"
        )

        if not confirm:
            return

        try:

            success, message = recognize_faces()

            if success:

                messagebox.showinfo(
                    "Nhận diện thành công",
                    message
                )

            else:

                messagebox.showwarning(
                    "Kết quả nhận diện",
                    message
                )

        except Exception as e:

            messagebox.showerror(
                "Lỗi",
                f"Không thể nhận diện khuôn mặt:\n{e}"
            )

    # ======================================================
    # LỊCH SỬ ĐIỂM DANH
    # ======================================================

    def show_history(self):

        self.clear_main()

        tk.Label(
            self.main_frame,
            text="Lịch sử điểm danh",
            bg=self.main_color,
            fg="#1f2a38",
            font=("Arial", 24, "bold")
        ).pack(
            anchor="w",
            padx=30,
            pady=(25, 5)
        )

        tk.Label(
            self.main_frame,
            text="Theo dõi và tìm kiếm lịch sử điểm danh",
            bg=self.main_color,
            fg="#666666",
            font=("Arial", 12)
        ).pack(
            anchor="w",
            padx=30,
            pady=(0, 15)
        )

        search_frame = tk.Frame(
            self.main_frame,
            bg="white"
        )
        search_frame.pack(
            fill="x",
            padx=30,
            pady=5
        )

        tk.Label(
            search_frame,
            text="Tìm kiếm:",
            bg="white",
            fg="#1f2a38",
            font=("Arial", 10, "bold")
        ).pack(
            side="left",
            padx=(15, 8),
            pady=12
        )

        self.txt_attendance_search = tk.Entry(
            search_frame,
            width=35,
            font=("Arial", 10)
        )
        self.txt_attendance_search.pack(
            side="left",
            padx=5,
            pady=12
        )
        self.txt_attendance_search.bind(
            "<Return>",
            lambda event: self.search_attendance_action()
        )

        tk.Button(
            search_frame,
            text="🔍 Tìm kiếm",
            command=self.search_attendance_action,
            bg="#2980b9",
            fg="white",
            font=("Arial", 10, "bold"),
            width=12,
            cursor="hand2"
        ).pack(side="left", padx=5)

        tk.Button(
            search_frame,
            text="🔄 Làm mới",
            command=self.load_attendance,
            bg="#27ae60",
            fg="white",
            font=("Arial", 10, "bold"),
            width=12,
            cursor="hand2"
        ).pack(side="left", padx=5)

        tk.Button(
            search_frame,
            text="Xóa tìm kiếm",
            command=self.clear_attendance_search,
            bg="#7f8c8d",
            fg="white",
            font=("Arial", 10, "bold"),
            width=14,
            cursor="hand2"
        ).pack(side="left", padx=5)

        table_frame = tk.Frame(
            self.main_frame,
            bg="white"
        )
        table_frame.pack(
            fill="both",
            expand=True,
            padx=30,
            pady=15
        )

        columns = (
            "AttendanceID",
            "StudentID",
            "FullName",
            "CheckInTime",
            "Status"
        )

        self.attendance_table = ttk.Treeview(
            table_frame,
            columns=columns,
            show="headings"
        )

        headings = {
            "AttendanceID": "ID",
            "StudentID": "Mã SV",
            "FullName": "Họ tên",
            "CheckInTime": "Thời gian điểm danh",
            "Status": "Trạng thái"
        }

        widths = {
            "AttendanceID": 70,
            "StudentID": 120,
            "FullName": 240,
            "CheckInTime": 190,
            "Status": 120
        }

        for column in columns:
            self.attendance_table.heading(
                column,
                text=headings[column]
            )
            self.attendance_table.column(
                column,
                width=widths[column],
                anchor="center"
            )

        self.attendance_table.column(
            "FullName",
            anchor="w"
        )

        scrollbar = ttk.Scrollbar(
            table_frame,
            orient="vertical",
            command=self.attendance_table.yview
        )
        self.attendance_table.configure(
            yscrollcommand=scrollbar.set
        )

        self.attendance_table.pack(
            side="left",
            fill="both",
            expand=True
        )
        scrollbar.pack(
            side="right",
            fill="y"
        )

        self.load_attendance()

    def load_attendance(self, rows=None):

        try:
            for item in self.attendance_table.get_children():
                self.attendance_table.delete(item)

            if rows is None:
                rows = get_all_attendance()

            for row in rows:
                values = list(row)

                if len(values) >= 4:
                    check_in_time = values[3]
                    if hasattr(check_in_time, "strftime"):
                        values[3] = check_in_time.strftime(
                            "%Y-%m-%d %H:%M:%S"
                        )

                self.attendance_table.insert(
                    "",
                    "end",
                    values=tuple(values)
                )

        except Exception as e:
            messagebox.showerror(
                "Lỗi",
                f"Không thể tải lịch sử điểm danh:\n{e}"
            )

    def search_attendance_action(self):

        keyword = (
            self.txt_attendance_search
            .get()
            .strip()
        )

        try:
            if not keyword:
                self.load_attendance()
                return

            from attendance import search_attendance

            rows = search_attendance(keyword)
            self.load_attendance(rows)

            if not rows:
                messagebox.showinfo(
                    "Kết quả tìm kiếm",
                    f"Không tìm thấy dữ liệu với từ khóa: {keyword}"
                )

        except Exception as e:
            messagebox.showerror(
                "Lỗi",
                f"Không thể tìm kiếm lịch sử điểm danh:\n{e}"
            )

    def clear_attendance_search(self):

        self.txt_attendance_search.delete(
            0,
            tk.END
        )
        self.load_attendance()

    # ======================================================
    # HUẤN LUYỆN MODEL
    # ======================================================

    def show_training(self):

        self.clear_main()

        tk.Label(
            self.main_frame,
            text="Huấn luyện mô hình",
            bg=self.main_color,
            fg="#1f2a38",
            font=("Arial", 24, "bold")
        ).pack(
            anchor="w",
            padx=30,
            pady=(30, 10)
        )

        tk.Label(
            self.main_frame,
            text="Huấn luyện mô hình nhận diện khuôn mặt LBPH",
            bg=self.main_color,
            fg="#666666",
            font=("Arial", 12)
        ).pack(
            anchor="w",
            padx=30
        )

        frame = tk.Frame(
            self.main_frame,
            bg="white"
        )

        frame.pack(
            fill="both",
            expand=True,
            padx=30,
            pady=30
        )

        tk.Label(
            frame,
            text="⚙ Huấn luyện LBPH",
            bg="white",
            fg="#1f2a38",
            font=("Arial", 18, "bold")
        ).pack(
            pady=(50, 15)
        )

        tk.Label(
            frame,
            text=(
                "Model được tạo từ dữ liệu trong thư mục dataset.\n\n"
                "Kết quả gồm:\n"
                "• face_model.yml\n"
                "• labels.txt"
            ),
            bg="white",
            fg="#555555",
            font=("Arial", 12),
            justify="left"
        ).pack(
            pady=10
        )

        tk.Button(
            frame,
            text="⚙ Bắt đầu huấn luyện",
            command=self.start_training,
            bg="#8e44ad",
            fg="white",
            font=("Arial", 11, "bold"),
            width=22,
            height=2,
            cursor="hand2"
        ).pack(
            pady=25
        )

    # ======================================================
    # CHẠY HUẤN LUYỆN
    # ======================================================

    def start_training(self):

        confirm = messagebox.askyesno(
            "Huấn luyện mô hình",
            "Bạn có muốn huấn luyện lại mô hình LBPH?"
        )

        if not confirm:
            return

        try:

            # Import module để chạy lại code huấn luyện
            import subprocess
            import sys
            from pathlib import Path

            train_file = (
                Path(__file__).resolve().parent
                / "train_model.py"
            )

            result = subprocess.run(
                [
                    sys.executable,
                    str(train_file)
                ],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace"
            )

            if result.returncode == 0:

                messagebox.showinfo(
                    "Huấn luyện thành công",
                    "Đã huấn luyện lại model LBPH thành công.\n\n"
                    "Đã tạo/cập nhật:\n"
                    "face_model.yml\n"
                    "labels.txt"
                )

            else:

                error = result.stderr.strip()

                if not error:
                    error = result.stdout.strip()

                messagebox.showerror(
                    "Huấn luyện thất bại",
                    error
                )

        except Exception as e:

            messagebox.showerror(
                "Lỗi",
                f"Không thể huấn luyện model:\n{e}"
            )

    # ======================================================
    # THOÁT
    # ======================================================

    def exit_app(self):

        confirm = messagebox.askyesno(
            "Xác nhận",
            "Bạn có muốn thoát chương trình không?"
        )

        if confirm:

            self.root.destroy()

    
# ==========================================================
# MAIN
# ==========================================================
    
if __name__ == "__main__":

    root = tk.Tk()

    app = FaceAttendanceApp(
        root
    )

    root.mainloop()
