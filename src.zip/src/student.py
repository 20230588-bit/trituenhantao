from database import (
    get_all_students as db_get_all_students,
    add_student as db_add_student,
    update_student as db_update_student,
    delete_student as db_delete_student,
    get_student as db_get_student
)


def get_all_students():
    return db_get_all_students()


def add_student(student_id, full_name, gender, date_of_birth, class_id):
    return db_add_student(
        student_id,
        full_name,
        gender,
        date_of_birth,
        class_id
    )


def update_student(student_id, full_name, gender, date_of_birth, class_id):
    return db_update_student(
        student_id,
        full_name,
        gender,
        date_of_birth,
        class_id
    )


def delete_student(student_id):
    return db_delete_student(student_id)


def get_student(student_id):
    return db_get_student(student_id)