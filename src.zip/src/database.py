import pyodbc


# ==========================================================
# CẤU HÌNH DATABASE
# ==========================================================

SERVER = r"localhost\MSSQLSERVER02"
DATABASE = "FaceAttendanceDB"

connection_string = (
    f"DRIVER={{ODBC Driver 17 for SQL Server}};"
    f"SERVER={SERVER};"
    f"DATABASE={DATABASE};"
    "Trusted_Connection=yes;"
    "TrustServerCertificate=yes;"
)


# ==========================================================
# KẾT NỐI DATABASE
# ==========================================================

def get_connection():
    return pyodbc.connect(connection_string)


# ==========================================================
# QUẢN LÝ SINH VIÊN
# ==========================================================

def get_all_students():
    conn = get_connection()

    try:
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                StudentID,
                FullName,
                Gender,
                DateOfBirth,
                ClassID,
                FaceFolder
            FROM Student
            ORDER BY StudentID
        """)

        return cursor.fetchall()

    finally:
        conn.close()


def get_student(student_id):
    conn = get_connection()

    try:
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                StudentID,
                FullName,
                Gender,
                DateOfBirth,
                ClassID,
                FaceFolder
            FROM Student
            WHERE StudentID = ?
        """, student_id)

        return cursor.fetchone()

    finally:
        conn.close()


def add_student(
    student_id,
    full_name,
    gender,
    date_of_birth,
    class_id
):
    conn = get_connection()

    try:
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO Student
            (
                StudentID,
                FullName,
                Gender,
                DateOfBirth,
                ClassID
            )
            VALUES (?, ?, ?, ?, ?)
        """,
        student_id,
        full_name,
        gender,
        date_of_birth,
        class_id
        )

        conn.commit()

    except Exception as e:
        conn.rollback()
        print("LOI ADD STUDENT:", e)
        raise

    finally:
        conn.close()


def update_student(
    student_id,
    full_name,
    gender,
    date_of_birth,
    class_id
):
    conn = get_connection()

    try:
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE Student
            SET
                FullName = ?,
                Gender = ?,
                DateOfBirth = ?,
                ClassID = ?
            WHERE StudentID = ?
        """,
        full_name,
        gender,
        date_of_birth,
        class_id,
        student_id
        )

        if cursor.rowcount == 0:
            raise Exception(
                f"Không tìm thấy sinh viên có mã {student_id}"
            )

        conn.commit()

    except Exception as e:
        conn.rollback()
        print("LOI UPDATE STUDENT:", e)
        raise

    finally:
        conn.close()


def delete_student(student_id):
    conn = get_connection()

    try:
        cursor = conn.cursor()

        cursor.execute("""
            DELETE FROM Student
            WHERE StudentID = ?
        """, student_id)

        if cursor.rowcount == 0:
            raise Exception(
                f"Không tìm thấy sinh viên có mã {student_id}"
            )

        conn.commit()

    except Exception as e:
        conn.rollback()
        print("LOI DELETE STUDENT:", e)
        raise

    finally:
        conn.close()


# ==========================================================
# CẬP NHẬT THƯ MỤC KHUÔN MẶT
# ==========================================================

def update_face_folder(student_id, face_folder):
    conn = get_connection()

    try:
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE Student
            SET FaceFolder = ?
            WHERE StudentID = ?
        """,
        face_folder,
        student_id
        )

        conn.commit()

    except Exception as e:
        conn.rollback()
        print("LOI UPDATE FACE FOLDER:", e)
        raise

    finally:
        conn.close()


# ==========================================================
# ĐIỂM DANH
# ==========================================================

def check_attendance_today(student_id):
    conn = get_connection()

    try:
        cursor = conn.cursor()

        cursor.execute("""
            SELECT COUNT(*)
            FROM Attendance
            WHERE StudentID = ?
              AND CAST(CheckInTime AS DATE)
                  = CAST(GETDATE() AS DATE)
        """, student_id)

        result = cursor.fetchone()

        return result[0] > 0

    finally:
        conn.close()


def add_attendance(student_id, status="Present"):
    conn = get_connection()

    try:
        cursor = conn.cursor()

        # Kiểm tra sinh viên đã điểm danh hôm nay chưa
        cursor.execute("""
            SELECT AttendanceID
            FROM Attendance
            WHERE StudentID = ?
              AND CAST(CheckInTime AS DATE)
                  = CAST(GETDATE() AS DATE)
        """, student_id)

        existing = cursor.fetchone()

        if existing:
            return False, "Sinh viên đã điểm danh hôm nay."

        # Thêm điểm danh
        cursor.execute("""
            INSERT INTO Attendance
            (
                StudentID,
                CheckInTime,
                Status
            )
            VALUES
            (
                ?,
                GETDATE(),
                ?
            )
        """,
        student_id,
        status
        )

        conn.commit()

        return True, "Điểm danh thành công."

    except Exception as e:
        conn.rollback()

        return False, f"Lỗi điểm danh: {e}"

    finally:
        conn.close()


def get_all_attendance():
    conn = get_connection()

    try:
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                AttendanceID,
                StudentID,
                CheckInTime,
                Status
            FROM Attendance
            ORDER BY CheckInTime DESC
        """)

        return cursor.fetchall()

    finally:
        conn.close()


def get_attendance_statistics():
    conn = get_connection()

    try:
        cursor = conn.cursor()

        # Tổng lượt điểm danh
        cursor.execute("""
            SELECT COUNT(*)
            FROM Attendance
        """)

        total = cursor.fetchone()[0]

        # Tổng số sinh viên từng điểm danh
        cursor.execute("""
            SELECT COUNT(DISTINCT StudentID)
            FROM Attendance
        """)

        total_students = cursor.fetchone()[0]

        # Tổng lượt điểm danh hôm nay
        cursor.execute("""
            SELECT COUNT(*)
            FROM Attendance
            WHERE CAST(CheckInTime AS DATE)
                  = CAST(GETDATE() AS DATE)
        """)

        today = cursor.fetchone()[0]

        return total, total_students, today

    finally:
        conn.close()


def search_attendance(student_id=""):
    conn = get_connection()

    try:
        cursor = conn.cursor()

        if student_id.strip() == "":
            cursor.execute("""
                SELECT
                    AttendanceID,
                    StudentID,
                    CheckInTime,
                    Status
                FROM Attendance
                ORDER BY CheckInTime DESC
            """)

        else:
            cursor.execute("""
                SELECT
                    AttendanceID,
                    StudentID,
                    CheckInTime,
                    Status
                FROM Attendance
                WHERE StudentID LIKE ?
                ORDER BY CheckInTime DESC
            """,
            "%" + student_id.strip() + "%"
            )

        return cursor.fetchall()

    finally:
        conn.close()


# ==========================================================
# THỐNG KÊ SINH VIÊN
# ==========================================================

def get_student_statistics():
    conn = get_connection()

    try:
        cursor = conn.cursor()

        # Tổng số sinh viên
        cursor.execute("""
            SELECT COUNT(*)
            FROM Student
        """)

        total_students = cursor.fetchone()[0]

        # Tổng số lớp
        cursor.execute("""
            SELECT COUNT(*)
            FROM Class
        """)

        total_classes = cursor.fetchone()[0]

        # Số lượt điểm danh hôm nay
        cursor.execute("""
            SELECT COUNT(*)
            FROM Attendance
            WHERE CAST(CheckInTime AS DATE)
                  = CAST(GETDATE() AS DATE)
        """)

        today_attendance = cursor.fetchone()[0]

        return (
            total_students,
            total_classes,
            today_attendance
        )

    finally:
        conn.close()


# ==========================================================
# THỐNG KÊ DASHBOARD
# ==========================================================

def get_dashboard_statistics():
    conn = get_connection()

    try:
        cursor = conn.cursor()

        # Tổng số sinh viên
        cursor.execute("""
            SELECT COUNT(*)
            FROM Student
        """)

        total_students = cursor.fetchone()[0]

        # Số sinh viên đã điểm danh hôm nay
        cursor.execute("""
            SELECT COUNT(DISTINCT StudentID)
            FROM Attendance
            WHERE CAST(CheckInTime AS DATE)
                  = CAST(GETDATE() AS DATE)
        """)

        attended_today = cursor.fetchone()[0]

        # Tổng lượt điểm danh hôm nay
        cursor.execute("""
            SELECT COUNT(*)
            FROM Attendance
            WHERE CAST(CheckInTime AS DATE)
                  = CAST(GETDATE() AS DATE)
        """)

        attendance_today = cursor.fetchone()[0]

        # Số sinh viên chưa điểm danh
        not_attended_today = (
            total_students - attended_today
        )

        return (
            total_students,
            attended_today,
            not_attended_today,
            attendance_today
        )

    finally:
        conn.close()